// Navigation scroll effect
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Mobile menu toggle
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
});

// Smooth scroll
function scrollToSection(id) {
    document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
}

// Active nav link
document.querySelectorAll('.nav-menu a').forEach(link => {
    link.addEventListener('click', function() {
        document.querySelectorAll('.nav-menu a').forEach(l => l.classList.remove('active'));
        this.classList.add('active');
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
    });
});

// Room filtering
const filterBtns = document.querySelectorAll('.filter-btn');
const roomCards = document.querySelectorAll('.room-card');

filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const filter = btn.getAttribute('data-filter');

        roomCards.forEach(card => {
            if (filter === 'all' || card.getAttribute('data-category') === filter) {
                card.style.display = 'block';
                card.style.animation = 'fadeIn 0.5s ease';
            } else {
                card.style.display = 'none';
            }
        });
    });
});

// Modal functions
function openLoginModal() {
    document.getElementById('loginModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeLoginModal() {
    document.getElementById('loginModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

function openBookingModal(roomName) {
    document.getElementById('bookingRoomName').textContent = roomName;
    document.getElementById('bookingModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeBookingModal() {
    document.getElementById('bookingModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Close modal on outside click
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
};

// Firebase Auth setup for student login
const firebaseConfig = {
    apiKey: 'AIzaSyCB52CH0zuLg5SEfBG4eh_zpkoEfIjqfkU',
    authDomain: 'shmaas-3a0c6.firebaseapp.com',
    projectId: '17356',
    storageBucket: 'shmaas-3a0c6.firebasestorage.app',
    messagingSenderId: '774113957832',
    appId: '1:774113957832:web:130f1dd20182665c49d2fd'
};

const DEMO_STUDENT_ACCOUNTS = [
    { email: 'student1@tvetmara.com', password: 'Student123!' },
    { email: 'student2@tvetmara.com', password: 'Student123!' }
];

function isFirebaseConfigured() {
    return firebaseConfig.apiKey !== '' &&
        firebaseConfig.projectId !== '' &&
        typeof window.firebase !== 'undefined';
}

let auth = null;

if (isFirebaseConfigured()) {
    try {
        if (!firebase.apps.length) {
            firebase.initializeApp(firebaseConfig);
        }
        auth = firebase.auth();
    } catch (error) {
        console.error('Firebase auth init failed:', error);
    }
}

async function loginStudentWithFirebase(email, password) {
    if (!auth) {
        throw new Error('firebase_not_configured');
    }

    try {
        await auth.signInWithEmailAndPassword(email, password);
    } catch (error) {
        const isDemoStudent = DEMO_STUDENT_ACCOUNTS.some(
            s => s.email === email && s.password === password
        );

        if ((error.code === 'auth/user-not-found' || error.code === 'auth/invalid-credential') && isDemoStudent) {
            await auth.createUserWithEmailAndPassword(email, password);
            await auth.signInWithEmailAndPassword(email, password);
            return;
        }

        throw error;
    }
}

// Login form handler
document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim().toLowerCase();
    const password = document.getElementById('loginPassword').value;

    // Admin login (local)
    if (email === 'admin@tvetmara.com' && password === 'admin123') {
        sessionStorage.setItem('isAdminAuthenticated', 'true');
        sessionStorage.removeItem('isStudentAuthenticated');
        sessionStorage.setItem('userEmail', email);
        showToast('Welcome Admin. Redirecting to dashboard...', 'success');
        setTimeout(() => {
            window.location.href = 'admin.html';
        }, 1200);
        return;
    }

    // Student login (Firebase)
    try {
        await loginStudentWithFirebase(email, password);
        sessionStorage.removeItem('isAdminAuthenticated');
        sessionStorage.setItem('isStudentAuthenticated', 'true');
        sessionStorage.setItem('userEmail', email);
        showToast('Student login successful. Redirecting...', 'success');
        setTimeout(() => {
            window.location.href = 'student.html';
        }, 1200);
    } catch (error) {
        if (String(error.message) === 'firebase_not_configured') {
            showToast('Firebase config missing. Add your Firebase keys first.', 'error');
            return;
        }

        showToast('Invalid login. Please check your email and password.', 'error');
    }
});

// Booking form handler
document.getElementById('bookingForm').addEventListener('submit', function(e) {
    e.preventDefault();
    showToast('Booking submitted. One bed per student rule applied.', 'success');
    closeBookingModal();
    this.reset();
});

// Contact form handler
document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    showToast('Message sent to hostel management.', 'success');
    this.reset();
});

// Toast notification
function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast show ${type}`;
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
        }
    });
}, observerOptions);

document.querySelectorAll('.feature-card, .room-card, .activity-card').forEach(el => {
    observer.observe(el);
});

// Set today's date for booking inputs
const today = new Date().toISOString().split('T')[0];
document.querySelectorAll('input[type="date"]').forEach(input => {
    input.min = today;
});


